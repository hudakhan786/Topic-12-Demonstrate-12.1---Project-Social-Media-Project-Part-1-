# settings.py
import django_heroku
django_heroku.settings(locals())
